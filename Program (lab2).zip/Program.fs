type Coach = {
    Name: string
    FormerPlayer: bool
}

type Stats = {
    w: int
    l: int
}

type Team = {
    Name: string
    Coach: Coach
    Stats: Stats
}
let gp = { Name = "Gregg Popovich"; FormerPlayer = false }
let jm = { Name = "Joe Mazzulla"; FormerPlayer = false }
let dh = { Name = "Darvin Ham"; FormerPlayer = true }
let fv = { Name = "Frank Vogel"; FormerPlayer = false }
let es = { Name = "Erik Spoelstra"; FormerPlayer = false }
let spursStats = { w = 2305; l = 1562 }
let celticsStats = { w = 3634; l = 2480 }
let lakersStats = { w = 3550; l = 2454 }
let sunsStats = { w = 1429; l = 2096 }
let heatStats = { w = 1221; l = 1364 }
let spurs = { Name = "San Antonio Spurs"; Coach = gp; Stats = spursStats }
let celtics = { Name = "Boston Celtics"; Coach = jm; Stats = celticsStats }
let lakers = { Name = "Los Angeles Lakers"; Coach = dh; Stats = lakersStats }
let suns = { Name = "Phoenix Suns"; Coach = fv; Stats = sunsStats }
let heat = { Name = "Miami Heat"; Coach = es; Stats = heatStats }

let teams = [spurs; celtics; lakers; suns; heat]
let isSuccessful team =
    team.Stats.w > team.Stats.l

let successfulTeams = List.filter isSuccessful teams
let successPercentage team =
    let wins = float team.Stats.w
    let losses = float team.Stats.l
    (wins / (wins + losses)) * 100.0

let teamsWithSuccessPercentage = 
    teams 
    |> List.map (fun team -> (team, successPercentage team))

printfn "All Teams with Details:"
teams |> List.iter (fun team ->
    printfn "Team: %s, Coach: %s, Former Player: %b, Wins: %d, Losses: %d" 
        team.Name team.Coach.Name team.Coach.FormerPlayer team.Stats.w team.Stats.l
)

printfn "\nSuccessful Teams:"
successfulTeams |> List.iter (fun team ->
    printfn "Team: %s, Wins: %d, Losses: %d" team.Name team.Stats.w team.Stats.l
)

printfn "\nTeams with Success Percentages:"
teamsWithSuccessPercentage |> List.iter (fun (team, percentage) ->
    printfn "Team: %s, Success Percentage: %.2f%%" team.Name percentage
)


type Cuisine =
    | Korean
    | Turkish
type MovieType =
    | Regular
    | IMAX
    | DBOX
    | RegularWithSnacks
    | IMAXWithSnacks
    | DBOXWithSnacks
type Activity =
    | BoardGame
    | Chill
    | Movie of MovieType
    | Restaurant of Cuisine
    | LongDrive of int * float
let calculateBudget activity =
    match activity with
    | BoardGame -> 2.0
    | Chill -> 2.0
    | Movie mt ->
        match mt with
        | Regular -> 14.0
        | IMAX -> 19.0
        | DBOX -> 22.0
        | RegularWithSnacks -> 19.0
        | IMAXWithSnacks -> 24.0
        | DBOXWithSnacks -> 27.0
    | Restaurant c ->
        match c with
        | Korean -> 72.0
        | Turkish -> 67.0
    | LongDrive (km, costPerKm) ->
        float km * costPerKm
let movieActivity = Movie IMAXWithSnacks
let restoActivity = Restaurant Korean
let driveActivity = LongDrive (100, 0.15)
let boardGameActivity = BoardGame
let chillActivity = Chill

printfn "Cost of movie activity: %.2f CAD" (calculateBudget movieActivity)
printfn "Cost of restaurant activity: %.2f CAD" (calculateBudget restoActivity)
printfn "Cost of drive activity: %.2f CAD" (calculateBudget driveActivity)
printfn "Cost of board game activity: %.2f CAD" (calculateBudget boardGameActivity)
printfn "Cost of chill activity: %.2f CAD" (calculateBudget chillActivity)







